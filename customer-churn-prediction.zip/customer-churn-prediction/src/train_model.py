from pathlib import Path
import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, RocCurveDisplay
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/"reports"; OUT.mkdir(exist_ok=True)
def main():
    df=pd.read_csv(ROOT/"data/customer_churn.csv")
    print("Rows/columns:",df.shape," | churn rate:",round(df.churn.mean(),3))
    print("Missing values:\\n",df.isna().sum())
    sns.set_theme()
    sns.countplot(data=df,x="contract_type",hue="churn")
    plt.title("Churn by contract type"); plt.tight_layout(); plt.savefig(OUT/"churn_by_contract.png",dpi=160); plt.close()
    sns.histplot(data=df,x="tenure_months",hue="churn",bins=24,element="step",stat="density",common_norm=False)
    plt.title("Tenure distribution by churn"); plt.tight_layout(); plt.savefig(OUT/"tenure_distribution.png",dpi=160); plt.close()
    X=df.drop(columns=["churn","customer_id"]); y=df.churn
    num=["tenure_months","monthly_charges","senior_citizen"]
    cat=["contract_type","internet_service","tech_support","payment_method"]
    prep=ColumnTransformer([("num",Pipeline([("imputer",SimpleImputer(strategy="median")),("scale",StandardScaler())]),num),
                           ("cat",Pipeline([("imputer",SimpleImputer(strategy="most_frequent")),("onehot",OneHotEncoder(handle_unknown="ignore"))]),cat)])
    Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
    models={"Logistic Regression":LogisticRegression(max_iter=1000,class_weight="balanced"),
            "Random Forest":RandomForestClassifier(n_estimators=250,min_samples_leaf=3,class_weight="balanced",random_state=42,n_jobs=-1)}
    results={}
    plt.figure(figsize=(7,6))
    for name,est in models.items():
        model=Pipeline([("prep",prep),("model",est)]); model.fit(Xtr,ytr)
        pred=model.predict(Xte); score=model.predict_proba(Xte)[:,1]
        results[name]={"accuracy":float(accuracy_score(yte,pred)),"precision":float(precision_score(yte,pred,zero_division=0)),
                       "recall":float(recall_score(yte,pred,zero_division=0)),"f1":float(f1_score(yte,pred,zero_division=0)),
                       "roc_auc":float(roc_auc_score(yte,score))}
        RocCurveDisplay.from_predictions(yte,score,name=name)
        print(name,results[name])
        if name=="Random Forest":
            cm=confusion_matrix(yte,pred)
            plt.figure(figsize=(5,4)); sns.heatmap(cm,annot=True,fmt="d",cbar=False,xticklabels=["Retained","Churn"],yticklabels=["Retained","Churn"])
            plt.xlabel("Predicted"); plt.ylabel("Actual"); plt.title("Random Forest confusion matrix"); plt.tight_layout(); plt.savefig(OUT/"confusion_matrix.png",dpi=160); plt.close()
            pd.DataFrame({"actual":yte.to_numpy(),"predicted":pred,"churn_probability":score}).to_csv(OUT/"test_predictions.csv",index=False)
    plt.title("ROC curves — held-out test set"); plt.tight_layout(); plt.savefig(OUT/"roc_curves.png",dpi=160); plt.close()
    (OUT/"model_metrics.json").write_text(json.dumps(results,indent=2),encoding="utf-8")
if __name__=="__main__": main()
