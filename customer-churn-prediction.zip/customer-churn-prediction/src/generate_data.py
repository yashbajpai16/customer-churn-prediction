import numpy as np
import pandas as pd
from pathlib import Path

def generate_data(n=1500, seed=42):
    rng=np.random.default_rng(seed)
    tenure=rng.integers(1,73,n)
    monthly=np.round(rng.normal(70,25,n).clip(18,160),2)
    contract=rng.choice(["Month-to-month","One year","Two year"],n,p=[.56,.24,.20])
    internet=rng.choice(["Fiber optic","DSL","No"],n,p=[.50,.38,.12])
    support=rng.choice(["Yes","No"],n,p=[.28,.72])
    payment=rng.choice(["Electronic check","Credit card","Bank transfer","Mailed check"],n)
    senior=rng.choice([0,1],n,p=[.84,.16])
    z=-2.2+.035*(monthly-65)-.045*(tenure-24)+1.0*(contract=="Month-to-month")-.55*(contract=="Two year")+.65*(support=="No")+.35*(internet=="Fiber optic")+.35*(payment=="Electronic check")+.35*senior
    churn=rng.binomial(1,1/(1+np.exp(-z)))
    return pd.DataFrame({"customer_id":[f"C{i:05d}" for i in range(1,n+1)],"tenure_months":tenure,"monthly_charges":monthly,"contract_type":contract,"internet_service":internet,"tech_support":support,"payment_method":payment,"senior_citizen":senior,"churn":churn})

if __name__=="__main__":
    path=Path(__file__).resolve().parents[1]/"data/customer_churn.csv"
    generate_data().to_csv(path,index=False)
    print("Dataset written:",path)
