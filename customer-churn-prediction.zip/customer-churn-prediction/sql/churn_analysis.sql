-- Assumes a table named customer_churn
SELECT COUNT(*) total_customers, SUM(churn) churned,
       ROUND(100.0*AVG(churn),2) churn_rate_pct
FROM customer_churn;

SELECT contract_type, COUNT(*) customers,
       ROUND(100.0*AVG(churn),2) churn_rate_pct
FROM customer_churn GROUP BY contract_type ORDER BY churn_rate_pct DESC;

SELECT CASE WHEN tenure_months<12 THEN '0-11 months'
            WHEN tenure_months<24 THEN '12-23 months'
            WHEN tenure_months<48 THEN '24-47 months'
            ELSE '48+ months' END tenure_segment,
       COUNT(*) customers, ROUND(100.0*AVG(churn),2) churn_rate_pct
FROM customer_churn GROUP BY tenure_segment;

SELECT churn, COUNT(*) customers, ROUND(AVG(monthly_charges),2) avg_monthly_charges
FROM customer_churn GROUP BY churn;

SELECT contract_type, tech_support, COUNT(*) customers,
       ROUND(100.0*AVG(churn),2) churn_rate_pct
FROM customer_churn GROUP BY contract_type, tech_support
ORDER BY churn_rate_pct DESC;
